#Imports
from operator import itemgetter
from random import randrange, seed
import pygame, sys
from health import *
from level import *
from exp import *
from enermy import *
from fastene import *
from chooseweapon import *
from crate import *
import json
#Constants--------------------------------------------------------------

seed()
pygame.init()
display = pygame.display.set_mode((WIDTH, HEIGHT))
TITLE = "SQUARE"
pygame.display.set_caption(TITLE)
clock = pygame.time.Clock()
play = False
start = True
endgame = False
pause = False
twenty=20
player = Player(WIDTH/2, HEIGHT/2, 32, 32, allthing[5][1])
def get_font(size):
    return pygame.font.SysFont("8-bit Madness",size)

myname = get_font(30).render("65010461 Thanpisit Suriyaroj",True,"#ffffff")
wait=0
#Main Loop-----------------------------------------------------
while True :
#Constants--------------------------------------------------------------
    allthing[0][1] = 0
    allthing[1][1] = 0
    allthing[2][1] = 1
    allthing[3][1] = 0
    allthing[4][1] = 0
    allthing[5][1] = 0
    movexp = 0
    updatescore = 0
    spawnguardian = False
    moving = 0
    guardiandmg = 0
    gundmg = 0
    forcedmg = 0
    delay = 0
    smach = 15
    lvl = 1
    exp = 0
    name = ""
    wait+=1
    sec = 0
    minute = 0
    playerhealth = 500
    damage = 0
    startxp = 300
    score = 0
    player_Gun = []
    player_guardian = []
    player_force = []
    player_health = [Health(playerhealth)]
    player_level = [Level(exp, lvl)]
    player_exp = []
    enermyspawn = []
    fastspawn = []
    crate_ = []
    hugeene = []
    bomba = []
    magnito = []

    mouse_x, mouse_y = pygame.mouse.get_pos()

#main menu--------------------------------------------------------------------------------------------------------------------
    display.fill((12, 24, 36))
    pygame.draw.polygon(display, (4,24,47) , ((WIDTH,0),(int(3/5*WIDTH)-WIDTH/6,HEIGHT),(WIDTH,HEIGHT)))
    pygame.draw.polygon(display, (10,20,60) , ((WIDTH,0),(int(3/5*WIDTH),HEIGHT),(WIDTH,HEIGHT)))
    square = get_font(150).render("SQUARE",start,"#ffffff")
    starttxt = get_font(70).render("START",start,"#ffffff")
    scoreboardtxt = get_font(70).render("SCOREBOARD",start,"#ffffff")
    exittxt = get_font(70).render("EXIT",start,"#ffffff")
    i=0
    white = 0
    while i <= 4 :
        i+=1
        white += 50
        pygame.draw.polygon(display, (100+i*30,70+i*10,10+i*10), ((550-i*10,300),(750-i*10,250),(750-i*10,450),(550-i*10,500)))
        pygame.draw.circle(display, (white,white,white), (800+white/5,150-white/5),int(white/7))
        pygame.draw.circle(display, (white,white,white), (700+white/5,550+white/5),int(white/7))

    if pygame.Rect.collidepoint(pygame.Rect(70,270,150,40),(mouse_x,mouse_y)) :
        starttxt = get_font(70).render("START",start,"#ffff17")
        if pygame.mouse.get_pressed()[0] : 
            inputname = True
            wait=0
#input name and play game-----------------------------------------------------------------------------------------------
            while inputname:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                display.fill((12, 24, 36))
                pygame.draw.polygon(display, (4,24,47) , ((WIDTH,0),(int(3/5*WIDTH)-WIDTH/6,HEIGHT),(WIDTH,HEIGHT)))
                pygame.draw.polygon(display, (10,20,60) , ((WIDTH,0),(int(3/5*WIDTH),HEIGHT),(WIDTH,HEIGHT)))
                pygame.draw.rect(display,(50,50,155),(0,300,WIDTH,120))
                inputurname = get_font(100).render("INPUT YOUR NAME",inputname,"#ffffff")
                enter = get_font(80).render("ENTER",inputname,"#ffffff")
                back = get_font(80).render("BACK",inputname,"#ffffff")
                if pygame.Rect.collidepoint(pygame.Rect(555,470,190,45),(mouse_x,mouse_y)):
                    enter = get_font(80).render("ENTER",inputname,"#ffff17")
                    if pygame.mouse.get_pressed()[0] :
                        inputname = False
                        play = True
                if pygame.Rect.collidepoint(pygame.Rect(150,470,155,45),(mouse_x,mouse_y)):
                    back = get_font(80).render("BACK",inputname,"#ffff17")
                    if pygame.mouse.get_pressed()[0] :
                        inputname = False
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_BACKSPACE:
                            name = name[:-1]
                        elif event.key == pygame.K_RETURN:
                            inputname = False
                            play = True
                        elif len(name) < 15:
                            name += event.unicode
                playername = get_font(100).render(str(name),inputname,"#ffaf17")
                display.blit(playername,(450-playername.get_width()/2,325))
                display.blit(inputurname,(450-inputurname.get_width()/2,180))
                display.blit(enter,(450+200-enter.get_width()/2,470))
                display.blit(back,(225-back.get_width()/2,470))
                
                pygame.display.flip()
#scoreboard------------------------------------------------------------------------------------------------------------
    elif pygame.Rect.collidepoint(pygame.Rect(70,400,345,40),(mouse_x,mouse_y)) and wait >=50:
        scoreboardtxt = get_font(70).render("SCOREBOARD",start,"#ffff17")
        if pygame.mouse.get_pressed()[0] :
            wait=0
            scoreboard = True
            while scoreboard :
                mouse_x, mouse_y = pygame.mouse.get_pos()
                display.fill((12, 24, 36))
                pygame.draw.polygon(display, (4,24,47) , ((WIDTH,0),(int(3/5*WIDTH)-WIDTH/6,HEIGHT),(WIDTH,HEIGHT)))
                pygame.draw.polygon(display, (10,20,60) , ((WIDTH,0),(int(3/5*WIDTH),HEIGHT),(WIDTH,HEIGHT)))
                with open('score.json') as file:
                    playerScore = json.load(file)
                playerScore = sorted(playerScore,reverse = True, key=itemgetter(1))
                if len(playerScore) > 5 :
                    playerScore.pop()

                scoreboardtxt = get_font(100).render("SCOREBOARD",scoreboard,"#ffff17")
                nametxt = get_font(70).render("NAME",scoreboard,"#ffff87")
                scoretxt = get_font(70).render("SCORE",scoreboard,"#ffff87")
                backtxt = get_font(70).render("BACK",scoreboard,"#ffffff")

                if pygame.Rect.collidepoint(pygame.Rect(750,10,140,40),(mouse_x,mouse_y)):
                    backtxt = get_font(70).render("BACK",scoreboard,"#ffff17")
                    if pygame.mouse.get_pressed()[0] : 
                        scoreboard = False

                for i in range(len(playerScore)):
                    playernametxt = get_font(70).render(str(playerScore[i][0]),scoreboard,"#ffffff")
                    display.blit(playernametxt, (130,260+i*80))
                    playerscoretxt = get_font(70).render(str(playerScore[i][1]),scoreboard,"#ffffff")
                    display.blit(playerscoretxt, (600,260+i*80))

                display.blit(scoreboardtxt, (206,80))
                display.blit(nametxt, (130,180))
                display.blit(scoretxt, (600,180))
                display.blit(backtxt, (750,10))
                display.blit(myname, (600,690))

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                pygame.display.flip()

    elif pygame.Rect.collidepoint(pygame.Rect(70,530,120,40),(mouse_x,mouse_y)) :
        exittxt = get_font(70).render("EXIT",start,"#ffff17")
        if pygame.mouse.get_pressed()[0] : 
            pygame.quit()
            sys.exit()

    display.blit(square, (70,70))
    display.blit(starttxt,(70,270))
    display.blit(scoreboardtxt,(70,400))
    display.blit(exittxt, (70, 530))
    display.blit(myname, (600,690))

    pygame.display.flip()
    for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
#playgame------------------------------------------------------------------------------------
    while play:

        mouse_x, mouse_y = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pause = True
            key = pygame.key.get_pressed()

            if key[pygame.K_a] :
                player.left_pressed = True
            else : player.left_pressed = False

            if key[pygame.K_d] :
                player.right_pressed = True
            else : player.right_pressed = False

            if key[pygame.K_w] :
                player.up_pressed = True
            else : player.up_pressed = False

            if key[pygame.K_s] :
                player.down_pressed = True
            else : player.down_pressed = False
#append-------------------------------------------------------------------------------------
        if allthing[2][1]<= 9 and delay%(20-allthing[2][1]*2)==0:
            player_Gun.append(Gun(x, y, mouse_x, mouse_y))
        elif allthing[2][1] > 9 and delay%2==0 : player_Gun.append(Gun(x, y, mouse_x, mouse_y))

        if allthing[0][1] > 0 and spawnguardian==False:
            spawnguardian=True
            angle = 180/allthing[0][1]
            for i in range(allthing[0][1]*2):
                player_guardian.append(Guardian(x,y,i,angle))

        if delay%600==0:
            crate_.append(Crate(x,y))

        if delay%(Force(x,y).maxrange/2)==0:
            player_force.append(Force(x,y))
                    
        if minute <= 6 and delay%int(45-minute*6-sec/60*6) == 0:#8# 10 20 40 80
            enermyspawn.append(Enermy(x,y,score))
        elif minute > 6 and delay%3 == 0: enermyspawn.append(Enermy(x,y,score))
        
        if minute <= 6 and delay%int(64-minute*8-sec/60*8) == 0:#8# 10 20 40 80
            fastspawn.append(fastene(x,y,score))
        elif minute > 6 and delay%8 == 0: fastspawn.append(fastene(x,y,score))

        display.fill((12, 24, 36))
        
        allenermy = set().union(enermyspawn,fastspawn,hugeene)

#force allenermy-----------------------------------------------
        for all in allenermy:
            for force in player_force:
                if force.x-force.range*4/5 <= all.x+all.size/2-display_scroll[0] and force.x+force.range*4/5 >= all.x-all.size/2-display_scroll[0]:
                    if force.y-force.range*4/5 <= all.y+all.size/2-display_scroll[1] and force.y+force.range*4/5 >= all.y-all.size/2-display_scroll[1]:
                        all.damage += allthing[1][1]*allthing[1][2]/2*(1+0.1*allthing[4][1])
                        forcedmg += allthing[1][1]*allthing[1][2]/2*(1+0.1*allthing[4][1])
            for cratee in crate_:
                if force.x-force.range*4/5 <= cratee.x+cratee.size/2 and force.x+force.range*4/5 >= cratee.x-cratee.size/2:
                    if force.y-force.range*4/5 <= cratee.y+cratee.size/2 and force.y+force.range*4/5 >= cratee.y-cratee.size/2:
                        cratee.damage = 1

#guardian allenermy--------------------------------------------
        for guardian in player_guardian:
            for all in allenermy:
                if guardian.x-guardian.r*4/5 <= all.x+all.size/2-display_scroll[0] and guardian.x+guardian.r*4/5 >= all.x-all.size/2-display_scroll[0]:
                    if guardian.y-guardian.r*4/5 <= all.y+all.size/2-display_scroll[1] and guardian.y+guardian.r*4/5 >= all.y-all.size/2-display_scroll[1]:
                        all.damage += allthing[0][1]*allthing[0][2]/2*(1+0.1*allthing[4][1])
                        guardiandmg += allthing[0][1]*allthing[0][2]/2*(1+0.1*allthing[4][1])
            for cratee in crate_:
                if guardian.x-guardian.r*4/5 <= cratee.x+cratee.size/2 and guardian.x+guardian.r*4/5 >= cratee.x-cratee.size/2:
                    if guardian.y-guardian.r*4/5 <= cratee.y+cratee.size/2 and guardian.y+guardian.r*4/5 >= cratee.y-cratee.size/2:
                        cratee.damage = 1

#shoot allenermy--------------------------------------------
        for all in allenermy:
            for bullet in player_Gun:
                if bullet.x-bullet.size*4/5 <= all.x+all.size/2-display_scroll[0] and bullet.x+bullet.size*4/5 >= all.x-all.size/2-display_scroll[0]:
                    if bullet.y-bullet.size*4/5 <= all.y+all.size/2-display_scroll[1] and bullet.y+bullet.size*4/5 >= all.y-all.size/2-display_scroll[1]:
                        player_Gun.remove(bullet)
                        all.damage += (1+allthing[2][1]/5*allthing[2][2])*(1+0.1*allthing[4][1])
                        gundmg += (1+allthing[2][1]/5*allthing[2][2])*(1+0.1*allthing[4][1])
                elif abs(bullet.x-x) >= 1000 or abs(bullet.y-y) >= 1000:
                    bullet.show = False
            for cratee in crate_:
                if bullet.x-bullet.size*4/5 <= cratee.x+cratee.size/2 and bullet.x+bullet.size*4/5 >= cratee.x-cratee.size/2:
                    if bullet.y-bullet.size*4/5 <= cratee.y+cratee.size/2 and bullet.y+bullet.size*4/5 >= cratee.y-cratee.size/2:
                        if cratee.x < 850 and cratee.x > 50 and cratee.y > 50 and cratee.y < 670 :
                            cratee.damage = 1
                        
#smach player-----------------------------------------------            
        for all in allenermy:
            if pygame.Rect.colliderect(player.rect,all.rect):
                if all in hugeene:
                    damage += 50-0.5*allthing[3][1]
                else:
                    damage += smach-0.5*allthing[3][1]
                all.damage += all.health

#spawn force-----------------------------------------------------
        for forcee in player_force: 
            forcee.main(display)
            if forcee.range <= 0:
                player_force.remove(forcee)

#map line--------------------------------------------------
        line = 0
        while line < 50 :
            pygame.draw.line(display,"#f0f0ff",(-10000-display_scroll[0]+line*1000,0),(-10000-display_scroll[0]+line*1000,HEIGHT))
            pygame.draw.line(display,"#f0f0ff",(0,-10000-display_scroll[1]+line*1000),(WIDTH,-10000-display_scroll[1]+line*1000))
            line+=1

#exp-------------------------------------------------------        
        for xp in player_exp:
            if pygame.Rect.colliderect(player.rect,xp.rect):
                dropxp = int(startxp/(1+(0.5)*(lvl-1)))
                exp += dropxp
                player_exp.remove(xp)
            xp.main(display)
#show bomb--------------------------------------------------
        for bomb in bomba:
            if pygame.Rect.colliderect(player.rect,bomb.rect):
                display.fill((255, 140, 140))
                bomba.remove(bomb)
                for all in allenermy:
                    all.damage += 10*(1+0.1*allthing[4][1])
            bomb.main(display)

#show magnet------------------------------------------------
        for magnet in magnito:
            if pygame.Rect.colliderect(player.rect,magnet.rect):
                magnito.remove(magnet)
                for xp in player_exp:
                    xp.move = True
                    moving = 1
            magnet.main(display)
        if moving == 1:
            movexp+=1
            if movexp >= 60:
                movexp=0
                moving=0

#crate spawn------------------------------------------------
        for cratee in crate_:
            if cratee.damage > 0:
                crate_.remove(cratee)
                soom = randint(1,5)
                if soom == 1:
                    hugeene.append(Huge(cratee.x+display_scroll[0],cratee.y+display_scroll[1],score))
                elif 2 <= soom <= 3:
                    bomba.append(Bomb(cratee.x+display_scroll[0],cratee.y+display_scroll[1]))
                elif 4 <= soom <= 5:
                    magnito.append(Magnet(cratee.x+display_scroll[0],cratee.y+display_scroll[1]))
            cratee.main(display)
            
#spawn fast-------------------------------------------------                
        for fast in fastspawn:
            if abs(fast.x-display_scroll[0]-x) > 2000 or abs(fast.y-display_scroll[1]-y) > 2000:
                fastspawn.remove(fast)
            elif fast.damage >= fast.health:
                fastspawn.remove(fast)
                score+=50
                if randrange(0,100)%int((lvl+9)/10)==0:
                    player_exp.append(Exp(fast.x,fast.y))
            if minute >= 4: 
                fast.speed = minute
            fast.main(display,x,y)

#spawn ene--------------------------------------------------
        for ene in enermyspawn:
            if abs(ene.x-display_scroll[0]-x) > 2000 or abs(ene.y-display_scroll[1]-y) > 2000:
                enermyspawn.remove(ene)
            elif ene.damage >= ene.health:
                enermyspawn.remove(ene)
                score+=50
                if randrange(0,100)%int((lvl+7)/8)==0:
                    player_exp.append(Exp(ene.x,ene.y))
            if minute >= 4 :
                ene.speed = minute*2/3
            ene.main(display,x,y)

#spawn Huge-------------------------------------------------
        for huge in hugeene:
            if huge.damage >= huge.health:
                hugeene.remove(huge)
                score+=500
            if minute >= 4 :
                ene.speed = minute/2
            huge.main(display)

#spawn guardian---------------------------------------------        
        for guardian in player_guardian:
            guardian.main(display)

#spawn gun--------------------------------------------------
        for bullet in player_Gun:
            if bullet.show == False:
                player_Gun.remove(bullet)
            bullet.main(display)

#interface game---------------------------------------------
        if damage < 0:
            damage = 0
        elif damage >= 500:
            endgame = True
            play = False
        for level in player_level:
            level.main(display,exp,lvl)  

        for health in player_health:
            health.main(display,damage)

        player.draw(display)
        player.update(allthing[5][1])
        
        if delay%60==0 : sec+=1 
        if sec==60 :
            sec=0
            minute+=1
        if minute < 10 : m = "0"
        else : m = ""
        if sec < 10 : s = "0"
        else : s = ""
        scoretxt = get_font(30).render("score : "+str(score),True,"#ffffff")
        display.blit(scoretxt,(10,35))
        timer = get_font(30).render(m+str(minute)+" : "+s+str(sec),True,"#ffffff")
        display.blit(timer,(420,35))
#level up---------------------------------------------------
        if exp >= WIDTH :
            lvl+=1
            exp-=WIDTH
            chosen = True
            seed()
            while True :
                one = randint(0,len(allthing)-1)
                two = randint(0,len(allthing)-1)
                three = randint(0,len(allthing)-1)
                list = [one, two, three]
                if one != two and one != three and two != three :
                    break                
                
            while chosen :
                mouse_x, mouse_y = pygame.mouse.get_pos()
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                chose = chooseweapon()
                chose.main(display,allthing[one][0] ,allthing[two][0] ,allthing[three][0])
                if pygame.Rect.collidepoint(pygame.Rect(100,170,200,350),(mouse_x,mouse_y)) :
                    pygame.draw.polygon(display,(90,50,50),((200,480),(170,510),(230,510)))
                    if pygame.mouse.get_pressed()[0] : 
                        allthing[one][1] += 1
                        chosen = False
                        if one == 0:   
                            player_guardian=[]
                            spawnguardian = False

                if pygame.Rect.collidepoint(pygame.Rect(350,170,200,350),(mouse_x,mouse_y)) :
                    pygame.draw.polygon(display,(90,50,50),((450,480),(420,510),(480,510)))
                    if pygame.mouse.get_pressed()[0] : 
                        allthing[two][1] += 1
                        chosen = False
                        if two == 0: 
                            player_guardian=[]
                            spawnguardian = False

                if pygame.Rect.collidepoint(pygame.Rect(600,170,200,350),(mouse_x,mouse_y)) :
                    pygame.draw.polygon(display,(90,50,50),((700,480),(670,510),(730,510)))
                    if pygame.mouse.get_pressed()[0] : 
                        allthing[three][1] += 1
                        chosen = False
                        if three == 0: 
                            player_guardian=[]
                            spawnguardian = False
                pygame.display.flip()
            damage -= 100

        playername = get_font(40).render(str(name),inputname,"#ff8f17")
        display.blit(playername,(450-playername.get_width()/2,305))
        display.blit(myname, (600,690))
        pygame.display.flip()
        delay+=1
        clock.tick(60)
#pause---------------------------------------------------------------------------------------------------------
        while pause :
            mouse_x, mouse_y = pygame.mouse.get_pos()
            display.fill((12, 24, 36))
            pygame.draw.polygon(display, (4,24,47) , ((WIDTH,0),(int(3/5*WIDTH)-WIDTH/6,HEIGHT),(WIDTH,HEIGHT)))
            pygame.draw.polygon(display, (10,20,60) , ((WIDTH,0),(int(3/5*WIDTH),HEIGHT),(WIDTH,HEIGHT)))
            i=0
            white = 0
            while i <= 4 :
                i+=1
                white += 50
                pygame.draw.polygon(display, (100+i*30,70+i*10,10+i*10), ((550-i*10,300),(750-i*10,250),(750-i*10,450),(550-i*10,500)))
                pygame.draw.circle(display, (white,white,white), (800+white/5,150-white/5),int(white/7))
                pygame.draw.circle(display, (white,white,white), (700+white/5,550+white/5),int(white/7))

            square = get_font(150).render("SQUARE",pause,"#ffffff")
            resumetxt = get_font(70).render("RESUME",pause,"#ffffff")
            retrytxt = get_font(70).render("RETRY",pause,"#ffffff")
            exittxt = get_font(70).render("EXIT",pause,"#ffffff")
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        pause = False

            if pygame.Rect.collidepoint(pygame.Rect(70,270,205,40),(mouse_x,mouse_y)) :
                resumetxt = get_font(70).render("RESUME",pause,"#ffff17")
                if pygame.mouse.get_pressed()[0] : 
                    pause = False
                
            elif pygame.Rect.collidepoint(pygame.Rect(70,400,165,40),(mouse_x,mouse_y)) :
                retrytxt = get_font(70).render("RETRY",pause,"#ffff17")
                if pygame.mouse.get_pressed()[0] : 
                    play = False
                    pause = False
                    allthing = [["guardian",0,0.1,2],["force",0,0.001,0],["gun",0,0.1,20],["hp",0,-5],["atk",0,1.1],["agi",0,1.1]]

            elif pygame.Rect.collidepoint(pygame.Rect(70,530,120,40),(mouse_x,mouse_y)) :
                exittxt = get_font(70).render("EXIT",pause,"#ffff17")
                if pygame.mouse.get_pressed()[0] : 
                    pygame.quit()
                    sys.exit()

            display.blit(square, (70,70))
            display.blit(resumetxt,(70,270))
            display.blit(retrytxt,(70,400))
            display.blit(exittxt, (70, 530))
            display.blit(myname, (600,690))

            pygame.display.flip()
#endgame--------------------------------------------------------------------------------------------------------
    while endgame :
        mouse_x, mouse_y = pygame.mouse.get_pos()

        display.fill((12, 24, 36))

        pygame.draw.polygon(display, (4,24,47) , ((WIDTH,0),(int(3/5*WIDTH)-WIDTH/6,HEIGHT),(WIDTH,HEIGHT)))
        pygame.draw.polygon(display, (10,20,60) , ((WIDTH,0),(int(3/5*WIDTH),HEIGHT),(WIDTH,HEIGHT)))

        square = get_font(150).render("YOU LOSE",endgame,"#ffffff")
        display.blit(square, (70,70))
        scoretxt = get_font(80).render("YOUR SCORE : "+str(score),endgame,"#ffffff")
        display.blit(scoretxt,(70,330))
        timer = get_font(80).render("PLAY TIME     "+m+str(minute)+" : "+s+str(sec),True,"#ffffff")
        display.blit(timer,(70,420))
        
        guardmgtxt  = get_font(60).render("guardian damage :   "+str(int(guardiandmg*10)),endgame,"#ffffff")
        gundmgtxt   = get_font(60).render("gun damage :             "+str(int(gundmg*10)),endgame,"#ffffff")
        forcedmgtxt = get_font(60).render("force damage :           "+str(int(forcedmg*10)),endgame,"#ffffff")
        backtxt = get_font(70).render("BACK",endgame,"#ffffff")

        if pygame.Rect.collidepoint(pygame.Rect(750,10,140,40),(mouse_x,mouse_y)):
            backtxt = get_font(70).render("BACK",endgame,"#ffff17")
            if pygame.mouse.get_pressed()[0] : 
                endgame = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        if updatescore == 0 :
            with open('score.json', 'r') as file:
                playerScore = json.load(file)
            playerScore.append([str(name),int(score)])
            playerScore = sorted(playerScore,reverse = True, key=itemgetter(1))
            if len(playerScore) > 5 :
                playerScore.pop()
            with open('score.json', 'w+') as file:
                json.dump(playerScore,file)
            updatescore=1

        nametxt = get_font(100).render(str(name),endgame,"#ffff17")
        display.blit(nametxt, ((450-nametxt.get_width()/2),210))
        display.blit(backtxt, (750,10))
        display.blit(guardmgtxt, (70,500))
        display.blit(gundmgtxt, (70,550))
        display.blit(forcedmgtxt, (70,600))
        display.blit(myname, (600,690))
        
        pygame.display.flip()