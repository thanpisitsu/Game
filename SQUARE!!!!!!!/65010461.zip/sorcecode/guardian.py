from allequipt import *
class Guardian:
    def __init__(self,x,y,i,angle):
        self.x = x
        self.y = y
        self.speed = 3
        self.angle= i*angle
        self.R = 160
        self.r = 30

    def main(self, display):
        self.x = WIDTH/2 + math.cos(math.radians(self.angle))* self.R
        self.y = HEIGHT/2 + math.sin(math.radians(self.angle))* self.R
        self.angle += self.speed
        pygame.draw.circle(display, (200,200,200), (self.x, self.y),self.r)
        pygame.draw.circle(display, (240,240,240), (self.x, self.y),self.r-1)