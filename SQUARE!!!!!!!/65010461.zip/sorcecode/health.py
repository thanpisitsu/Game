from player import *
import pygame

class Health:
    def __init__(self,health):
        self.x = 0
        self.y = 10
        self.width = 500
        self.height = 20
        self.health = health

    def main(self, display ,damage):
        pygame.draw.rect(display, (255,255,255), (self.x, self.y, self.width, self.height))
        pygame.draw.rect(display, (255,0,0), (self.x, self.y, self.health-damage, self.height))