from player import *
from random import *
from cratething import *

class Crate:
    def __init__(self,x,y):
        seed()
        while True:
            self.randx = randint(-1,1)
            self.randy = randint(-1,1)
            if not (abs(self.randx) == 0 and abs(self.randy) == 0):
                break
        self.startx = x+self.randx*WIDTH
        self.starty = y+self.randy*HEIGHT
        self.x = 0
        self.y = 0
        self.size = 40
        self.color = (90,50,50)
        self.color2 = (210,210,50)
        self.damage = 0
        self.rect = pygame.Rect(self.x-self.size/2,self.y-self.size/2,self.size,self.size)

    def main(self, display):
        self.x = self.startx-display_scroll[0]
        self.y = self.starty-display_scroll[1]
        self.rect = pygame.Rect(self.x-self.size/2,self.y-self.size/2,self.size,self.size)
        pygame.draw.rect(display, self.color ,self.rect)
        pygame.draw.rect(display, self.color2 ,(self.x-self.size/2,self.y-self.size/2,self.size,self.size),1)
        pygame.draw.rect(display, self.color2 ,(self.x-self.size/2,self.y-self.size/10,self.size,self.size/5))
        pygame.draw.rect(display, self.color2 ,(self.x-self.size/10,self.y-self.size/2,self.size/5,self.size))