from re import L
from player import *
from exp import *

def get_font(size):
    return pygame.font.SysFont("8-bit Madness",size)

class Level:
    def __init__(self, exp, lvl):
        self.xlv = 550
        self.ylv = 10
        self.width = 100
        self.height = 20
        self.xbar = 0
        self.ybar = HEIGHT-10
        
    def main(self, display, exp, lvl):
        pygame.draw.rect(display, (200,200,0), (WIDTH-self.width-20, self.ylv, self.width+20, self.height)) #show lv
        level = get_font(25).render("LEVEL "+str(lvl),True,(12, 24, 36))
        display.blit(level,(WIDTH-self.width,12))
        pygame.draw.rect(display, (0,0,0), (self.xbar, self.ybar, WIDTH, 10)) #expbar
        pygame.draw.rect(display, (170,170,170), (self.xbar, self.ybar+1, WIDTH, 8)) #expbar
        pygame.draw.rect(display, (255,255,0), (self.xbar, self.ybar+1, exp, 8)) #exp
