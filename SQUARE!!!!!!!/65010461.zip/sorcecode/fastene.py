from player import *
from random import *

class fastene:
    def __init__(self,x,y,score):
        seed()
        while True:
            self.randx = uniform(-1.5,1.5)
            self.randy = uniform(-1.5,1.5)
            if not (abs(self.randx) <= 1 and abs(self.randy) <= 1):
                break
        self.x = x+display_scroll[0]+self.randx*(randrange(0,500)+WIDTH*4/5)
        self.y = y+display_scroll[1]+self.randy*(randrange(0,500)+HEIGHT*4/5)
        self.size = 30
        self.rect = (self.x-display_scroll[0]-1, (self.y-display_scroll[1]-1), self.size, self.size)
        self.rectin = (self.x-display_scroll[0], (self.y-display_scroll[1]), self.size-2, self.size-2)
        self.speed = 4
        self.health = 70+score/210
        self.angle = math.atan2(y-self.y, x-self.x)
        self.x_vel = math.cos(self.angle) * self.speed
        self.y_vel = math.sin(self.angle) * self.speed
        self.damage = 0
        
    def main(self, display, x ,y):
        self.angle = math.atan2(y-self.y+display_scroll[1], x-self.x+display_scroll[0])
        self.x_vel = math.cos(self.angle) * self.speed
        self.y_vel = math.sin(self.angle) * self.speed
        self.x += self.x_vel
        self.y += self.y_vel
        self.health -= self.damage
        self.rect = (self.x-self.size/2-display_scroll[0]-1, (self.y-self.size/2-display_scroll[1]-1), self.size, self.size)
        self.rectin = (self.x-self.size/2-display_scroll[0], (self.y-self.size/2-display_scroll[1]), self.size-2, self.size-2)
        pygame.draw.rect(display, (0,0,0), self.rect)
        pygame.draw.rect(display, (0,0,150), self.rectin)