from random import randint
from player import *
from guardian import*
from gun import *
from force import *

def get_font(size):
    return pygame.font.SysFont("8-bit Madness",size)

class chooseweapon :
    def __init__ (self) :
        self.rect1 = pygame.Rect(100,190,200,320)
        self.rect2 = pygame.Rect(350,190,200,320)
        self.rect3 = pygame.Rect(600,190,200,320)
        self.colorout = (90,50,50)
        self.colorin = (150,150,70)
        self.list = []

    def main(self,display,one , two ,three) :
        myname = get_font(30).render("65010461 Thanpisit Suriyaroj",True,"#ffffff")
        display.blit(myname, (600,690))
        pygame.draw.rect(display,self.colorout,self.rect1)
        pygame.draw.rect(display,self.colorout,self.rect2)
        pygame.draw.rect(display,self.colorout,self.rect3)
        pygame.draw.rect(display,self.colorin,(110,200,180,300))
        pygame.draw.rect(display,self.colorin,(360,200,180,300))
        pygame.draw.rect(display,self.colorin,(610,200,180,300))

        self.list = [one , two ,three]
        for i in range(3):
            match self.list[i]:
                case "guardian" :
                    Guardiantxt = get_font(50).render("Guardian",True,"#ffffff")
                    display.blit(Guardiantxt,(120+250*i,215))
                    lvGuardiantxt = get_font(30).render("lv : "+str(allthing[0][1]),True,"#ffffff")
                    display.blit(lvGuardiantxt,(120+250*i,260))
                    dtGuardiantxt = get_font(30).render("+ amount",True,"#ffffff")
                    dt2Guardiantxt = get_font(30).render("+ damage",True,"#ffffff")
                    display.blit(dtGuardiantxt,(120+250*i,290))
                    display.blit(dt2Guardiantxt,(120+250*i,320))
                    for j in range(3):
                        for k in range(3):
                            pygame.draw.circle(display,((160+40*k,160+40*k,160+40*k)),(200+250*i+math.cos(math.pi*j*2/3-0.25*k)*50,410+math.sin(math.pi*j*2/3-0.25*k)*50),10+5*k)
                case "force" :
                    Forcetxt = get_font(50).render("Force",True,"#ffffff")
                    display.blit(Forcetxt,(120+250*i,215))
                    lvGuardiantxt = get_font(30).render("lv : "+str(allthing[1][1]),True,"#ffffff")
                    display.blit(lvGuardiantxt,(120+250*i,260))
                    dtForcetxt = get_font(30).render("+ range",True,"#ffffff")
                    dt2Forcetxt = get_font(30).render("+ damage",True,"#ffffff")
                    display.blit(dtForcetxt,(120+250*i,290))
                    display.blit(dt2Forcetxt,(120+250*i,320))
                    for j in range(3):
                        pygame.draw.circle(display,((12,174-20*j,36)),(200+250*i,420),60-j*20)
                case "gun" :
                    Guntxt = get_font(50).render("Gun",True,"#ffffff")
                    display.blit(Guntxt,(120+250*i,215))
                    lvGuardiantxt = get_font(30).render("lv : "+str(allthing[2][1]),True,"#ffffff")
                    display.blit(lvGuardiantxt,(120+250*i,260))
                    dtGuntxt = get_font(30).render("- fire rate",True,"#ffffff")
                    dt2Guntxt = get_font(30).render("+ distribution",True,"#ffffff")
                    display.blit(dtGuntxt,(120+250*i,290))
                    display.blit(dt2Guntxt,(120+250*i,320))
                    for j in range(3):
                        for k in range(2):
                            pygame.draw.circle(display,((150+j*50,150+j*50,150+j*50)),(160+250*i+k*50+j*10,450-k*50-j*10),10+j*5)
                case "hp" :
                    healthtxt = get_font(50).render("Health",True,"#ffffff")
                    display.blit(healthtxt,(120+250*i,215))
                    lvGuardiantxt = get_font(30).render("lv : "+str(allthing[3][1]),True,"#ffffff")
                    display.blit(lvGuardiantxt,(120+250*i,260))
                    dtHptxt = get_font(30).render("+ Health 50",True,"#ffffff")
                    display.blit(dtHptxt,(120+250*i,290))
                    pygame.draw.rect(display,(0,255,0),(180+250*i,370,20,100))
                    pygame.draw.rect(display,(0,255,0),(140+250*i,410,100,20))
                    pygame.draw.rect(display,(255,0,0),(240+250*i,370,10,30))
                    pygame.draw.rect(display,(255,0,0),(230+250*i,380,30,10))
                case "atk" :
                    atktxt = get_font(50).render("Attack",True,"#ffffff")
                    display.blit(atktxt,(120+250*i,215))
                    lvGuardiantxt = get_font(30).render("lv : "+str(allthing[4][1]),True,"#ffffff")
                    display.blit(lvGuardiantxt,(120+250*i,260))
                    dtAtktxt = get_font(30).render("+ attack 10%",True,"#ffffff")
                    display.blit(dtAtktxt,(120+250*i,290))
                    pygame.draw.polygon(display,(100,100,100),((190+250*i,350),(210+250*i,370),(200+250*i,430),(180+250*i,430),(170+250*i,370)))
                    pygame.draw.polygon(display,(100,100,100),((190+250*i,350),(210+250*i,370),(200+250*i,430),(180+250*i,430),(170+250*i,370)),2)
                    pygame.draw.rect(display,(90,50,50),(170+250*i,430,40,20))
                    pygame.draw.rect(display,(90,50,50),(180+250*i,450,20,20))
                    pygame.draw.rect(display,(255,0,0),(240+250*i,370,10,30))
                    pygame.draw.rect(display,(255,0,0),(230+250*i,380,30,10))
                case "agi" :
                    agitxt = get_font(50).render("Speed",True,"#ffffff")
                    display.blit(agitxt,(120+250*i,215))
                    lvGuardiantxt = get_font(30).render("lv : "+str(allthing[5][1]),True,"#ffffff")
                    display.blit(lvGuardiantxt,(120+250*i,260))
                    dtAgitxt = get_font(30).render("+ speed 10%",True,"#ffffff")
                    display.blit(dtAgitxt,(120+250*i,290))
                    pygame.draw.rect(display,(255,0,0),(230+250*i,380,30,10))
                    pygame.draw.line(display,(200,200,200),(130+250*i,400),(150+250*i,400),4)
                    pygame.draw.line(display,(200,200,200),(125+250*i,420),(145+250*i,420),4)
                    pygame.draw.line(display,(200,200,200),(127+250*i,440),(155+250*i,440),4)
                    pygame.draw.line(display,(200,200,200),(132+250*i,460),(170+250*i,460),4)
                    pygame.draw.polygon(display,(60,60,150),((181+250*i,470),(169+250*i,460),(160+250*i,370),(200+250*i,366),(206+250*i,426),(246+250*i,423),(256+250*i,434),(258+250*i,454),(248+250*i,465)))
                    pygame.draw.polygon(display,(200,200,250),((158+250*i,390),(156+250*i,370),(204+250*i,366),(206+250*i,386)))
                    pygame.draw.rect(display,(255,0,0),(240+250*i,370,10,30))
                case "regen" :
                    regentxt = get_font(50).render("Regen",True,"#ffffff")
                    display.blit(regentxt,(120+250*i,215))
                    lvGuardiantxt = get_font(30).render("lv : "+str(allthing[6][1]),True,"#ffffff")
                    display.blit(lvGuardiantxt,(120+250*i,260))
                    dtAgitxt = get_font(30).render("+ regen 1% /5s",True,"#ffffff")
                    display.blit(dtAgitxt,(120+250*i,290))
