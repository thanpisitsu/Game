from allequipt import *
class Force:
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.range = 10 
        self.color = 174
        self.colorchange = 0
        self.rangechange = 1
        if allthing[1][1] == 0 : self.maxrange = 1 
        else : self.maxrange = 60+30*int(allthing[1][1])
        self.hitbox = pygame.Rect(x-self.maxrange*4/5,y-self.maxrange*4/5,self.maxrange*8/5,self.maxrange*8/5)
    
    def main(self, display):
        self.hitbox = pygame.Rect(x-self.maxrange*4/5,y-self.maxrange*4/5,self.maxrange*8/5,self.maxrange*8/5)
        self.colorchange += float(150/self.maxrange)
        if self.colorchange >= 1 and self.color > 24:
            self.color -= int(self.colorchange)
            self.colorchange -= int(self.colorchange)
        if self.range >= self.maxrange :
            self.rangechange = -1
        self.range += self.rangechange
        if self.color <= 24 :
            self.color = 24
        pygame.draw.circle(display, (12,self.color,36), (self.x ,self.y), self.range)

force = Force(x,y)