from player import *
allthing = [["guardian",0,0.05,2],["force",0,0.012,0],["gun",1,0.5],["hp",0],["atk",0],["agi",0]]
# equip , lv , damage , range/amount