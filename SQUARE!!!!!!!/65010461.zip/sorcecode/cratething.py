from player import *

class Huge:
    def __init__(self,x,y,score):
        self.x = x
        self.y = y
        self.size = 100
        self.rect = (self.x-display_scroll[0]-1, (self.y-display_scroll[1]-1), self.size, self.size)
        self.rectin = (self.x-display_scroll[0], (self.y-display_scroll[1]), self.size-2, self.size-2)
        self.speed = 1
        self.health = 1000+score/10
        self.angle = math.atan2(y-self.y, x-self.x)
        self.x_vel = math.cos(self.angle) * self.speed
        self.y_vel = math.sin(self.angle) * self.speed
        self.damage = 0
        
    def main(self, display):
        self.angle = math.atan2(y-self.y+display_scroll[1], x-self.x+display_scroll[0])
        self.x_vel = math.cos(self.angle) * self.speed
        self.y_vel = math.sin(self.angle) * self.speed
        self.x += self.x_vel
        self.y += self.y_vel
        self.health -= self.damage
        self.rect = (self.x-self.size/2-display_scroll[0]-1, (self.y-self.size/2-display_scroll[1]-1), self.size, self.size)
        self.rectin = (self.x-self.size/2-display_scroll[0], (self.y-self.size/2-display_scroll[1]), self.size-2, self.size-2)
        pygame.draw.rect(display, (0,0,0), self.rect)
        pygame.draw.rect(display, (100,150,150), self.rectin)

class Magnet:
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.size = 30
        self.rect = (self.x-self.size/2, self.y-self.size/2, self.size, self.size)

    def main(self, display):
        self.rect = (self.x-self.size/2-display_scroll[0], self.y-self.size/2-display_scroll[1], self.size, self.size)
        pygame.draw.rect(display,(0,0,250),(self.x-self.size/2-display_scroll[0], self.y-self.size/2-display_scroll[1], self.size, self.size))
        pygame.draw.rect(display,(250,0,0),(self.x-display_scroll[0], self.y-self.size/2-display_scroll[1], self.size/2, self.size))
        pygame.draw.rect(display,(250,250,250),(self.x-self.size/2-display_scroll[0], self.y-self.size/2-display_scroll[1], self.size, self.size/4))
        pygame.draw.rect(display,(12,24,36),(self.x-self.size/4-display_scroll[0], self.y-self.size/2-display_scroll[1], self.size/2, self.size*3/4))

class Bomb:
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.size = 15
        self.rect = (self.x-self.size, self.y-self.size, self.size*2, self.size*2)

    def main(self, display):
        self.rect = (self.x-self.size/2-display_scroll[0], self.y-self.size/2-display_scroll[1], self.size, self.size)
        pygame.draw.rect(display,(250,250,0),(self.x-2.5-display_scroll[0], self.y-self.size-5-display_scroll[1], 5, 8))
        pygame.draw.circle(display,(0,0,0),(self.x-display_scroll[0], self.y-display_scroll[1]), self.size)
        pygame.draw.circle(display,(250,250,250),(self.x-display_scroll[0], self.y-display_scroll[1]), self.size,2)
        pygame.draw.circle(display,(250,250,250),(self.x+5-display_scroll[0], self.y-5-display_scroll[1]), self.size/5)