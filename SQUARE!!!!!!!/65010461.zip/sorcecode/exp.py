from player import *

class Exp:
    def __init__(self,x,y):
        self.x = x - 6
        self.y = y - 6
        self.size = 10
        self.color = (0,200,0) 
        self.rect = (self.x-display_scroll[0], (self.y-display_scroll[1]), self.size, self.size)
        self.speed = 30
        self.angle = math.atan2(y-self.y+display_scroll[1],x-self.x+display_scroll[0])
        self.x_vel = math.cos(self.angle) * self.speed
        self.y_vel = math.sin(self.angle) * self.speed
        self.move = False

    def main(self, display):
        if self.move:
            self.angle = math.atan2(y-self.y+display_scroll[1], x-self.x+display_scroll[0])
            self.x_vel = math.cos(self.angle) * self.speed
            self.y_vel = math.sin(self.angle) * self.speed
            self.x += self.x_vel
            self.y += self.y_vel
        self.rect = (self.x-display_scroll[0], (self.y-display_scroll[1]), self.size, self.size)
        pygame.draw.rect(display, self.color,self.rect) 