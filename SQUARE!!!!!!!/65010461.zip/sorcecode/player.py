import pygame, math
from health import *
display_scroll = [0, 0]
WIDTH, HEIGHT = 900, 720
x,y=WIDTH/2,HEIGHT/2
delay=0

lvl = 1

class Player:
    def __init__(self, x, y, width, height, run):
        x = int(x)
        y = int(y)
        self.width = int(width)
        self.height = int(height)
        self.rect = pygame.Rect(x, y, width, height)
        self.color = (250, 120, 60)
        self.velX = 0
        self.velY = 0
        self.left_pressed = False
        self.right_pressed = False
        self.up_pressed = False
        self.down_pressed = False
        self.player_speed = 5*(1+0.1*run)
    
    def draw(self, display):
        pygame.draw.rect(display, self.color, self.rect)

    def update(self,run):
        self.velX = 0   # for player move
        self.velY = 0   # scroll = for player move but center
        if (self.left_pressed or self.right_pressed) and (self.up_pressed or self.down_pressed): 
            self.player_speed = math.sqrt(15)*(1+0.1*run)
        else :
            self.player_speed = 5*(1+0.1*run)
        if self.left_pressed and not self.right_pressed:
            display_scroll[0] -= self.player_speed

        if self.right_pressed and not self.left_pressed:
            display_scroll[0] += self.player_speed

        if self.up_pressed and not self.down_pressed:
            display_scroll[1] -= self.player_speed

        if self.down_pressed and not self.up_pressed:
            display_scroll[1] += self.player_speed

        self.rect = pygame.Rect(x-24, y-24, 48, 48)